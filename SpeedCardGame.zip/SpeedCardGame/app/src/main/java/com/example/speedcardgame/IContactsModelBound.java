package com.example.speedcardgame;

public interface IContactsModelBound {
    public abstract void getIMatch();
    public abstract boolean isEmailUsing();
    public abstract boolean isMailValid();
}
